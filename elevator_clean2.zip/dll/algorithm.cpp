void CDispatchW::Algorithm7(double CurrentTime, lift l[MAX_LIFTS], double SimulationTimeStep,
                            building b, int NoLifts, CString message, CString &mode, CArray<person *, person *> &PersonArray, int NoPassengers, int NoTrafficPeriods,
                            double m_u[MAX_TRAFFIC_PERIODS][MAX_FLOORS], double m_d[MAX_TRAFFIC_PERIODS][MAX_FLOORS][MAX_FLOORS],
                            double m_StartTime[MAX_TRAFFIC_PERIODS], double m_EndTime[MAX_TRAFFIC_PERIODS],
                            DestinationCall DestCalls[MAX_DESTINATION_CALLS], CString Document, bool DestinationButtons[MAX_FLOORS], int UserSelectedMode)
{
    UserSelectedMode;   //warning C4100: 'UserSelectedMode' : unreferenced formal parameter
    DestinationButtons; //warning C4100: 'DestinationButtons' : unreferenced formal parameter
    m_EndTime;          //warning C4100: 'm_EndTime' : unreferenced formal parameter
    m_StartTime;        //warning C4100: 'm_StartTime' : unreferenced formal parameter
    m_d;                //warning C4100: 'm_d' : unreferenced formal parameter
    m_u;                //warning C4100: 'm_u' : unreferenced formal parameter
    NoTrafficPeriods;   //warning C4100: 'NoTrafficPeriods' : unreferenced formal parameter
    NoPassengers;       //warning C4100: 'NoPassengers' : unreferenced formal parameter
    PersonArray;        //warning C4100: 'PersonArray' : unreferenced formal parameter
    mode;               //warning C4100: 'mode' : unreferenced formal parameter
    SimulationTimeStep; //warning C4100: 'SimulationTimeStep' : unreferenced formal parameter
    CurrentTime;        //warning C4100: 'CurrentTime' : unreferenced formal parameter
    CurrentTime;        //warning C4100: 'UserSelectedMode' : unreferenced formal parameter

    //从elevate获取环境数据

    //up_wait，down_wait;load_up, load_down;loading map
    int *up_wait, *down_wait, *load_up, *load_down;
    int **loading_map;

    //intialize
    loading_map = new int *[NoLifts];
    for (int i = 0; i < NoLifts; ++i)
    {
        loading_map[i] = new int[b.m_NOFLOORS]();
    }
    up_wait = new int[b.m_NOFLOORS](); //楼层范围为1-b.m_NOFLOORS，对应数组位置0-b.m_NOFLOORS-1
    down_wait = new int[b.m_NOFLOORS]();
    load_up = new int[NoLifts]();
    load_down = new int[NoLifts]();

    //check by person
    for (int i = 0; i < PersonArray.GetSize(); ++i)
    {
        //person is waiting(包括正在上电梯)
        if (PersonArray[i]->m_CurrentStatus == 2 || PersonArray[i]->m_CurrentStatus == 3)
        {
            //wait up
            if (PersonArray[i]->m_Destination > PersonArray[i]->m_ArrivalFloor)
                up_wait[PersonArray[i]->m_ArrivalFloor - 1]++;
            //wait down
            else
                down_wait[PersonArray[i]->m_ArrivalFloor - 1]++;
        }

        //person is being loaded
        else if (PersonArray[i]->m_CurrentStatus == 4)
        {
            //loading_map
            loading_map[PersonArray[i]->m_LiftUsed][PersonArray[i]->m_Destination - 1]++;
            //load up
            if (PersonArray[i]->m_Destination > PersonArray[i]->m_ArrivalFloor)
                load_up[PersonArray[i]->m_LiftUsed]++; //这里我假设电梯编号为0-NoLifts-1，若elevate所给的编号为1·NoLifts，则需要-1
            //load down
            else
                load_down[PersonArray[i]->m_LiftUsed]++;
        }
    }

    //location
    double *location;
    location = new double[NoLifts]();
    for (int i = 0; i < NoLifts; ++i)
    {
        location[i] = l[i].m_CurrentPosition / b.BuildingHeight(); //归一化为0-1
    }

    //up_call, down_call
    bool **up_call, **down_call;
    //intialize
    up_call = new bool *[NoLifts];
    down_call = new bool *[NoLifts];
    for (int i = 0; i < NoLifts; ++i)
    {
        up_call[i] = new bool[b.m_NOFLOORS]();
        down_call[i] = new bool[b.m_NOFLOORS]();
    }
    //calc
    for (int i = 0; i < NoLifts; ++i)
    {
        for (int j = 0; j < b.m_NOFLOORS; ++j)
        {
            if (l[i].m_UpLandingCalls[j + 1] == 1)
                up_call[i][j] = 1;
            if (l[i].m_DownLandingCalls[j + 1] == 1)
                down_call[i][j] = 1;
        }
    }

    /*将获取到的数据传递给python文件*/
    //open py module
    Py_Initialize();
    if (!Py_IsInitialized())
    {
        cout << "python init fail" << endl;
        return;
    }
    PyRun_SimpleString("import sys");
    PyRun_SimpleString("sys.path.append('./script')"); //取决于实际目录
    PyObject *pModule = PyImport_ImportModule("pip install PyQt5");
    if (pModule == NULL)
    {
        cout << "module not found" << endl;
        return;
    }

    //open function
    //initialize函数
    static bool first_open_module = 0;
    if (first_open_module == 0)
    {
        first_open_module = 1;

        PyObject *pFunc = PyObject_GetAttrString(pModule, "initialize");
        if (!pFunc || !PyCallable_Check(pFunc))
        {
            cout << "not found function initialize" << endl;
            return;         
        }
        PyObject_CallObject(pFunc, NULL);
    }
    //action函数
    PyObject *pFunc = PyObject_GetAttrString(pModule, "get_action");
    if (!pFunc || !PyCallable_Check(pFunc))
    {
        cout << "not found function get_action" << endl;
        return;
    }

    /*将c参数转换成python参数*/
    //up_wait,downwait
    PyObject *up_wait_py = PyList_New(b.m_NOFLOORS), *down_wait_py = PyList_New(b.m_NOFLOORS);
    for (int i = 0; i < b.m_NOFLOORS; ++i)
    {
        PyObject *item = Py_BuildValue("i", up_wait[i]);
        PyList_Append(up_wait_py, item);

        PyObject *item = Py_BuildValue("i", down_wait[i]);
        PyList_Append(down_wait_py, item);
    }

    //load up,load down
    PyObject *load_up_py = PyList_New(NoLifts), *load_down_py = PyList_New(NoLifts);
    for (int i = 0; i < NoLifts; ++i)
    {
        PyObject *item = Py_BuildValue("i", load_up[i]);
        PyList_Append(load_up_py, item);

        PyObject *item = Py_BuildValue("i", load_down[i]);
        PyList_Append(load_down_py, item);
    }

    //loading map
    PyObject *loading_py = PyList_New(NoLifts);
    for (int i = 0; i < NoLifts; ++i)
    {
        PyObject *item_list = PyList_New(b.m_NOFLOORS);

        for (int j = 0; i < b.m_NOFLOORS; ++j)
        {
            PyObject *item = Py_BuildValue("i", loading_map[i][j]);
            PyList_Append(item_list, item);
        }

        PyList_Append(loading_py, item_list);
    }

    //location
    PyObject *location_py = PyList_New(NoLifts);
    for (int i = 0; i < NoLifts; ++i)
    {
        PyObject *item = Py_BuildValue("d", location[i]);
        PyList_Append(location_py, item);
    }

    //up_call, down_call
    PyObject *up_call_py = PyList_New(NoLifts), *down_call_py = PyList_New(NoLifts);
    for (int i = 0; i < NoLifts; ++i)
    {
        PyObject *item_list_up = PyList_New(b.m_NOFLOORS);
        PyObject *item_list_down = PyList_New(b.m_NOFLOORS);

        for (int j = 0; i < b.m_NOFLOORS; ++j)
        {
            if (up_call[i][j] == 1)
            {
                PyObject *item = Py_BuildValue("i", j + 1);
                PyList_Append(item_list_up, item);
            }

            if (down_call[i][j] == 1)
            {
                PyObject *item = Py_BuildValue("i", j + 1);
                PyList_Append(item_list_down, item);
            }
        }

        PyList_Append(up_call_py, item_list_up);
        PyList_Append(down_call_down, item_list_down);
    }

    //elev running direction.
    PyObject *direction_py = PyList_New(NoLifts);
    for (int i = 0; i < NoLifts; ++i)
    {
        PyObject *item = Py_BuildValue("i", l[i].m_Direction);
        PyList_Append(location_py, item);
    }

    //elev position
    PyObject *position_py = PyList_New(NoLifts);
    for (int i = 0; i < NoLifts; ++i)
    {
        PyObject *item = Py_BuildValue("d", l[i].m_CurrentPosition);
        PyList_Append(position_py, item);
    }




    //合并所有参数
    PyObject *args = PyList_New(8);
    PyList_Append(args, up_wait_py);
    PyList_Append(args, down_wait_py);
    PyList_Append(args, loading_py);
    PyList_Append(args, location_py);
    PyList_Append(args, up_call_py);
    PyList_Append(args, down_call_py);
    PyList_Append(args, load_up_py);
    PyList_Append(args, load_down_py);
    PyList_Append(args, direction_py);
    PyList_Append(args, position_py);

    /*调用函数并处理返回参数，得到action*/
    int *action;
    action = new int[b.m_NOFLOORS*2];

    PyObject *pVal = PyObject_CallObject(pFunc, args);
    int val_size = PyList_Size(pVal);
    for (int i = 0; i < val_size; ++i)
    {
        PyObject *pRet = PyList.GetItem(pVal, i);
        PyArg_Parse(pRet, "i", &action[i]);
        ++action[i];
    }

    //release space
    Py_CLEAR(pFunc);
    Py_CLEAR(pModule);
    Py_CLEAR(args);
    Py_CLEAR(up_wait_py);
    Py_CLEAR(down_wait_py);
    Py_CLEAR(loading_py);
    Py_CLEAR(location_py);
    Py_CLEAR(up_call_py);
    Py_CLEAR(down_call_py);
    Py_CLEAR(load_up_py);
    Py_CLEAR(load_down_py);
    Py_CLEAR(direction_py);
    Py_CLEAR(position_py);
    Py_CLEAR(pVal);

    Py_Finalize();

    delete[] up_wait;
    delete[] down_wait;
    delete[] location;
    delete[] load_up;
    delete[] load_down;
    for (int i = 0; i < NoLifts; ++i)
    {
        delete[] up_call[i];
        delete[] down_call[i];
        delete[] loading_map[i];
    }
    delete[] up_call;
    delete[] down_call;
    delete[] loading_map;

    /*处理调梯请求*/
    /*//allocate the destination calls
    for (int ctr = 0; ctr < MAX_DESTINATION_CALLS; ctr++)
    {
        if (DestCalls[ctr].m_Status == NOT_IN_USE)
        {
            continue;
        }
        //
        //does this call need allocating?
        if (DestCalls[ctr].m_Status == ALLOCATED && DestCalls[ctr].m_LiftAllocated == 0)
        {
            int Allocate = action[DestCalls[ctr].m_ArrivalFloor - 1];

            DestCalls[ctr].m_LiftAllocated = Allocate;
            //if the lift is currently at that floor, make sure person does not miss the lift by reseting the doors
            if (l[Allocate].FloorAt() == DestCalls[ctr].m_ArrivalFloor)
            {
                l[Allocate].ResetDoorDwellTimers();
            }
        }
    }*/
    //
    //allocate the conventional calls
    for (int i = 1; i <= b.m_NoFloors; i++)
    {
        if (!DestinationButtons[i]) //only consider floors without destination input
        {
            //allocate all the conventional calls to car 1 for example purposes only!
            if (m_UpLandingCalls[i] == 1)
            {
                l[action[i - 1]].m_UpLandingCalls[i] = 1;
                m_UpLandingCalls[i] = 0;
            }

            if (m_DownLandingCalls[i] == 1)
            {
                l[action[i - 1+b.m_NoFloors]].m_DownLandingCalls[i] = 1;
                m_DownLandingCalls[i] = 0;
            }
        }
    }

    delete[] action;
    return;
}