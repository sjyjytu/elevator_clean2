import numpy as np
import torch
import os
from dll.smec_rl_components.smec_policy import SmecPolicy
from dll.smec_rl_components.smec_graph_build import *

model_path = ''
elevator_num = 4
floor_num = 16
floor_height = 3
actor_critic = SmecPolicy(elevator_num, floor_num, open_mask=False, use_advice=False)
device = 'cpu'
# obs = {}
gb = GraphBuilder(elevator_num, floor_num, 'cpu')
cur_adj_matrix = gb.get_zero_adj_matrix()
cur_node_feature = gb.get_zero_node_feature()
use_advice = False


def initialize():
    exp_name = "oct22"
    # choose a model
    model_path = "oct22.pt"
    global actor_critic
    actor_critic = torch.load(model_path, map_location=device)[0]


def get_filter_by_list(list_len, query):
    cur_elv_mask = torch.tensor([0.0 for _ in range(list_len)])
    for elev in query:
        cur_elv_mask[elev] = 1.0
    return cur_elv_mask


def get_floor_position(flr):
    return flr * floor_height


def calc_sync_floor(pos):
    lower_floor = 0
    upper_floor = floor_num - 1

    while upper_floor - lower_floor > 1:
        mid_floor = lower_floor + upper_floor
        mid_floor = mid_floor >> 1
        tmp_position = get_floor_position(mid_floor)
        if pos >= tmp_position:
            lower_floor = mid_floor
        else:
            upper_floor = mid_floor

    tmp_position = get_floor_position(lower_floor)
    tmp_position += get_floor_position(upper_floor)
    tmp_position /= 2

    if pos <= tmp_position:
        floor = lower_floor
    else:
        floor = upper_floor

    return floor


def get_convenience_elevators(elev_dir, elev_syn_floor, up_or_down, floor_id):
    convenient_elevators = []
    if up_or_down:  # moving up
        for idx in range(elevator_num):
            if elev_dir[idx] >= 0 and elev_syn_floor[idx] < floor_id:
                convenient_elevators.append(idx)
    else:
        for idx in range(elevator_num):
            if elev_dir[idx] <= 0 and elev_syn_floor[idx] > floor_id:
                convenient_elevators.append(idx)
    return convenient_elevators


def get_action_mask(elev_dir, elev_syn_floor):
    # # M JY: add advice choice
    candidate_num = elevator_num + 1 if use_advice else elevator_num
    # candidate_num = elevator_num

    # get a list of action candidates by rules given pre-defined floors.
    floor2elv_masks = []
    # handle up floors
    for idx in range(floor_num):
        conv_elevators = get_convenience_elevators(elev_dir, elev_syn_floor, up_or_down=True, floor_id=idx)
        if len(conv_elevators) > 0:  # convenient elevators exist
            cur_elv_mask = get_filter_by_list(candidate_num, conv_elevators)
            if use_advice:
                cur_elv_mask[-1] = 1.0
        else:
            cur_elv_mask = torch.tensor([1.0 for _ in range(candidate_num)])
        floor2elv_masks.append(cur_elv_mask)

    # handle down floors
    for idx in range(floor_num):
        conv_elevators = get_convenience_elevators(elev_dir, elev_syn_floor, up_or_down=False, floor_id=idx)
        if len(conv_elevators) > 0:  # convenient elevators exist
            cur_elv_mask = get_filter_by_list(candidate_num, conv_elevators)
            if use_advice:
                cur_elv_mask[-1] = 1.0
        else:
            cur_elv_mask = torch.tensor([1.0 for _ in range(candidate_num)])
        floor2elv_masks.append(cur_elv_mask)

    elevator_mask = torch.stack(floor2elv_masks).to(device)
    return elevator_mask


def get_floor2elevator_dis(elev_dir, elev_syn_floor):
    floor2elevator_dis = []
    for call_floor in range(floor_num):  # up calls
        cur_distance = []
        for idx in range(elevator_num):
            elevator_floor = elev_syn_floor[idx]
            going_up = elev_dir[idx] == 1  # going up
            if going_up and call_floor >= elevator_floor:
                distance = call_floor - elevator_floor  # directly move up
            elif going_up and call_floor < elevator_floor:
                distance = (floor_num - elevator_floor) + floor_num + call_floor  # move up + move to bottom + move to call
            else:
                distance = elevator_floor + call_floor  # down to bottom and move up
            cur_distance.append(distance / floor_num)  # normalize
        floor2elevator_dis.append(cur_distance)

    for call_floor in range(floor_num):  # down calls
        cur_distance = []
        for idx in range(elevator_num):
            elevator_floor = elev_syn_floor[idx]
            going_down = elev_dir[idx] != 1  # going down
            if going_down and call_floor <= elevator_floor:
                distance = elevator_floor - call_floor  # directly move down
            elif going_down and call_floor > elevator_floor:
                distance = elevator_floor + floor_num + (
                            floor_num - call_floor)  # move down + move to top + move to call
            else:
                distance = (floor_num - elevator_floor) + (floor_num - call_floor)  # to top and move down
            cur_distance.append(distance / floor_num)  # normalize
        floor2elevator_dis.append(cur_distance)
    floor2elevator_dis = torch.tensor(floor2elevator_dis).to(device)
    return floor2elevator_dis


def get_action(up_wait, down_wait, loading, location, up_call, down_call, load_up, load_down, elev_dir, elev_pos):
    # TODO: also need some info from the mansion, such as the unallocate floor,
    #  the uncalled elevators (or the convenient elevators). need to know the elevator_floor, direction
    elev_syn_floor = []
    for elev_idx in range(elevator_num):
        elev_syn_floor.append(calc_sync_floor(elev_pos[elev_idx]))

    # wrap the input into obs. Written from the get_smec_state() function from smec_rl_env.py
    up_wait, down_wait, loading, location = torch.tensor(up_wait), torch.tensor(down_wait), torch.tensor(
        loading), torch.tensor(location)

    legal_masks = get_action_mask(elev_dir, elev_syn_floor)

    global cur_adj_matrix, cur_node_feature
    cur_adj_matrix = gb.update_adj_matrix(cur_adj_matrix, up_call, down_call)
    cur_node_feature = gb.update_node_feature(cur_node_feature, up_wait, down_wait, load_up,
                                                        load_down, location)
    distances = get_floor2elevator_dis(elev_dir, elev_syn_floor)
    obs = {'adj_m': cur_adj_matrix, 'node_feature_m': cur_node_feature, 'legal_masks': legal_masks,
            'distances': distances}

    # get action
    with torch.no_grad():
        for k in obs:
            obs[k] = obs[k].to(device).unsqueeze(0)
        _, action, _, rule = actor_critic.act(obs, deterministic=True)

    # return action
    return action


if __name__ == '__main__':
    initialize()
    print(actor_critic)
    # a = get_action()
