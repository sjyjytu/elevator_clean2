gamma = 0.98
lmbda = 0.95
eps_clip = 0.1
K_epoch = 3
T_horizon = 20

add_people_at_step = 25
add_people_prob = 0.8
print_interval = 20
global_step = 0
MAX_PASSENGERS_LENGTH = 40
MAX_ELV_LENGTH = 10
