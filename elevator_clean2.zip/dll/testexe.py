import numpy as np
import torch
import os
import sys

argv = sys.argv
model_path = argv[1]
device = argv[2]

if torch.cuda.is_available():
    device = torch.device(device)
else
    device = 'cpu'
ac = torch.load(model_path, map_location=device)[0]
print('success!')
