import os
import numpy as np
import pickle
import glob
from csv import reader, writer
import queue

data_dir = './down_data'
data_file = './down_data/4Ele16FloorDnPeakFlow1_elvx.csv'
collected_data = queue.Queue()
dt = 60
t = 3600
iter_num = t // dt
floor_num = 16

save_dir = './out_data'
save_start_file = 'visualize_start.csv'
save_end_file = 'visualize_end.csv'

files = os.listdir(data_dir)


def process(look_back=5, save=False):
    data_x = []
    data_y = []
    for file in files:
        data_file = os.path.join(data_dir, file)
        start_data = [[0 for _ in range(floor_num)] for i in range(iter_num)]
        end_data = [[0 for _ in range(floor_num)] for i in range(iter_num)]
        with open(data_file, 'rt', encoding='utf8', errors='ignore') as f:
            r = reader(f)
            row = None
            for i in range(274):
                row = next(r)
            while True:
                time, start_level, end_level = row[0], int(row[1].replace('Level ', ''))-1, int(row[2].replace('Level ', ''))-1
                next_person_time = time.split(':')
                nt = int(next_person_time[-2]) * 60 + float(next_person_time[-1])
                # print(nt, int(nt)//dt)
                start_data[int(nt)//dt][start_level] += 1
                end_data[int(nt)//dt][end_level] += 1
                row = next(r)
                if len(row) < 14 or row[0]=='':
                    break
            if save:
                save_start_file = os.path.join(save_dir, 'start_'+file)
                save_end_file = os.path.join(save_dir, 'end_'+file)
                with open(save_start_file, 'w', newline='') as wf:
                    w = writer(wf)
                    for d in start_data:
                        w.writerow(d)
                with open(save_end_file, 'w', newline='') as wf:
                    w = writer(wf)
                    for d in end_data:
                        w.writerow(d)

        # print(start_data)
        # max_value = np.max(start_data)
        # min_value = np.min(start_data)
        m = np.mean(start_data)
        v = np.var(start_data)
        datas = list(map(lambda x: (x-m) / v, start_data))
        # print(max_value)
        # print(min_value)
        # print(datas)
        for i in range(len(datas)-look_back):
            data_x.append(datas[i:i+look_back])
            data_y.append(datas[i+1:i+look_back+1])
    return np.asarray(data_x), np.asarray(data_y)


# x, y = process()
# print(len(x))
# print(len(y))


import torch
from torch.autograd import Variable
import torch.nn as nn
import matplotlib.pyplot as plt
import numpy as np
import random

look_back=30
dataX, dataY = process(look_back)

index = [i for i in range(len(dataX))]
random.shuffle(index)
train_size = int(len(dataX)*0.8)
train_index = index[:train_size]
test_index = index[train_size:]

x_train = dataX[train_index] #训练数据  385*5*16
y_train = dataY[train_index] #训练数据目标值  385*16
x_test = dataX[test_index]
y_test = dataY[test_index]


# x_train = x_train.reshape(-1, 1, 16) #将训练数据调整成pytorch中lstm算法的输入维度
# y_train = y_train.reshape(-1, 1, 16)  #将目标值调整成pytorch中lstm算法的输出维度

#  #将ndarray数据转换为张量，因为pytorch用的数据类型是张量

x_train = torch.from_numpy(x_train)
y_train = torch.from_numpy(y_train)
x_test = torch.from_numpy(x_test)
y_test = torch.from_numpy(y_test)

print(x_train.shape)
print(y_train.shape)


class RNN(nn.Module):
    def __init__(self):
        super(RNN,self).__init__() #面向对象中的继承
        self.lstm = nn.LSTM(16, 32, 2, batch_first=True) #输入数据2个特征维度，6个隐藏层维度，2个LSTM串联，第二个LSTM接收第一个的计算结果
        self.out = nn.Linear(32, 16) #线性拟合，接收数据的维度为6，输出数据的维度为1

    def forward(self,x):
        x1,_ = self.lstm(x)
        a,b,c = x1.shape
        out = self.out(x1.reshape(a*b,c)) #因为线性层输入的是个二维数据，所以此处应该将lstm输出的三维数据x1调整成二维数据，最后的特征维度不能变
        out1 = out.reshape(a,b,-1) #因为是循环神经网络，最后的时候要把二维的out调整成三维数据，下一次循环使用
        return out1

# lstm = nn.LSTM(16, 16, 2, batch_first=True)
lstm = RNN()


# train
optimizer = torch.optim.Adam(lstm.parameters(), lr=0.02)
loss_func = nn.MSELoss()

for i in range(1000):
    var_x = Variable(x_train).type(torch.FloatTensor)
    var_y = Variable(y_train).type(torch.FloatTensor)
    # out, _ = lstm(var_x)
    out = lstm(var_x)
    # print(out.shape)
    # print(var_y.shape)
    loss = loss_func(out, var_y)
    # loss = loss_func(out[:,-1,:], var_y[:,-1,:])
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    if (i + 1) % 100 == 0: # 每 100 次输出结果
        print('Epoch: {}, Loss: {:.5f}'.format(i + 1, loss.item()))
torch.save(lstm.state_dict(), 'lstm.pt', _use_new_zipfile_serialization=False)

# test
lstm = lstm.eval() # 转换成测试模式
var_x = Variable(x_test).type(torch.FloatTensor)
var_y = Variable(y_test).type(torch.FloatTensor)
# out, _ = lstm(var_x)
out = lstm(var_x)
loss = loss_func(out, var_y)
# loss = loss_func(out[:,-1,:], var_y[:,-1,:])
print('Test Loss: {:.5f}'.format(loss.item()))


# # test all and plot:
# lstm.load_state_dict(torch.load('lstm.pt'))
# data_X = dataX
# data_X = torch.from_numpy(data_X)
# var_data = Variable(data_X).type(torch.FloatTensor)
# pred_test = lstm(var_data).detach().numpy() # 测试集的预测结果 torch.Size([550, 5, 16])

# for idx in range(16):
#
#     # idx = 1
#     plt.figure()
#     plt.title('floor %d' % (idx+1))
#     pred = pred_test[:,-1,idx]
#     plt.plot(pred, 'r', label='prediction')
#     plt.plot(dataX[:,-1,idx], 'b', label='real')
#     # plt.plot(np.array(dataX[:,-1,idx]-pred_test), 'y', label='dist')
#     plt.legend(loc='best')
#     plt.show()

# pred_test = pred_test[:,-1,:]
# dataX = dataX[:,-1,:]
# print(pred_test.shape)
# pred = np.argmax(pred_test, axis=1)
# real = np.argmax(dataX, axis=1)
# print(np.sum(pred==real))
# print(pred.shape)
