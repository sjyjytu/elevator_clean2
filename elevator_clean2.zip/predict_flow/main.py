import torch
from torch.autograd import Variable
import torch.nn as nn
import pandas as pd
from pandas import DataFrame
import matplotlib.pyplot as plt
import numpy as np
from predict_flow.read_data import process, process2
import random

look_back=30
dataX, dataY = process(look_back)

index = [i for i in range(len(dataX))]
random.shuffle(index)
train_size = int(len(dataX)*0.8)
train_index = index[:train_size]
test_index = index[train_size:]

x_train = dataX[train_index] #训练数据  385*5*16
y_train = dataY[train_index] #训练数据目标值  385*16
x_test = dataX[test_index]
y_test = dataY[test_index]


# x_train = x_train.reshape(-1, 1, 16) #将训练数据调整成pytorch中lstm算法的输入维度
# y_train = y_train.reshape(-1, 1, 16)  #将目标值调整成pytorch中lstm算法的输出维度

#  #将ndarray数据转换为张量，因为pytorch用的数据类型是张量

x_train = torch.from_numpy(x_train)
y_train = torch.from_numpy(y_train)
x_test = torch.from_numpy(x_test)
y_test = torch.from_numpy(y_test)

print(x_train.shape)
print(y_train.shape)


class RNN(nn.Module):
    def __init__(self):
        super(RNN,self).__init__() #面向对象中的继承
        self.lstm = nn.LSTM(16, 32, 2, batch_first=True) #输入数据2个特征维度，6个隐藏层维度，2个LSTM串联，第二个LSTM接收第一个的计算结果
        self.out = nn.Linear(32, 16) #线性拟合，接收数据的维度为6，输出数据的维度为1

    def forward(self,x):
        x1,_ = self.lstm(x)
        a,b,c = x1.shape
        out = self.out(x1.reshape(a*b,c)) #因为线性层输入的是个二维数据，所以此处应该将lstm输出的三维数据x1调整成二维数据，最后的特征维度不能变
        out1 = out.reshape(a,b,-1) #因为是循环神经网络，最后的时候要把二维的out调整成三维数据，下一次循环使用
        return out1

# lstm = nn.LSTM(16, 16, 2, batch_first=True)
lstm = RNN()


# # train
# optimizer = torch.optim.Adam(lstm.parameters(), lr=0.02)
# loss_func = nn.MSELoss()
#
# for i in range(1000):
#     var_x = Variable(x_train).type(torch.FloatTensor)
#     var_y = Variable(y_train).type(torch.FloatTensor)
#     # out, _ = lstm(var_x)
#     out = lstm(var_x)
#     # print(out.shape)
#     # print(var_y.shape)
#     loss = loss_func(out, var_y)
#     # loss = loss_func(out[:,-1,:], var_y[:,-1,:])
#     optimizer.zero_grad()
#     loss.backward()
#     optimizer.step()
#     if (i + 1) % 100 == 0: # 每 100 次输出结果
#         print('Epoch: {}, Loss: {:.5f}'.format(i + 1, loss.item()))
# torch.save(lstm.state_dict(), 'lstm.pt')
#
# # test
# lstm = lstm.eval() # 转换成测试模式
# var_x = Variable(x_test).type(torch.FloatTensor)
# var_y = Variable(y_test).type(torch.FloatTensor)
# # out, _ = lstm(var_x)
# out = lstm(var_x)
# loss = loss_func(out, var_y)
# # loss = loss_func(out[:,-1,:], var_y[:,-1,:])
# print('Test Loss: {:.5f}'.format(loss.item()))


# # test all and plot:
# lstm.load_state_dict(torch.load('lstm.pt'))
# data_X = dataX
# data_X = torch.from_numpy(data_X)
# var_data = Variable(data_X).type(torch.FloatTensor)
# pred_test = lstm(var_data).detach().numpy() # 测试集的预测结果 torch.Size([550, 5, 16])
#
# for idx in range(16):
#
#     # idx = 1
#     plt.figure()
#     plt.title('floor %d' % (idx+1))
#     pred = pred_test[:120,-1,idx]
#     plt.plot(pred, 'r', label='prediction')
#     plt.plot(dataX[:120 ,-1,idx], 'b', label='real')
#     # plt.plot(np.array(dataX[:,-1,idx]-pred_test), 'y', label='dist')
#     plt.legend(loc='best')
#     plt.show()

# pred_test = pred_test[:,-1,:]
# dataX = dataX[:,-1,:]
# print(pred_test.shape)
# pred = np.argmax(pred_test, axis=1)
# real = np.argmax(dataX, axis=1)
# print(np.sum(pred==real))
# print(pred.shape)



# # just draw up
# dataX, _ = process2()
# idx = 0
# plt.figure()
# plt.title('floor %d' % (idx+1))
# # pred = pred_test[:200,-1,idx]
# # plt.plot(pred, 'r', label='prediction')
# print(dataX.shape)
# plotX = dataX[:,:,idx]
# # plt.scatter(np.arange(plotX.shape[0]), plotX, s=3)
# # plt.plot(plotX, 'b', label='real')
# # plt.plot(np.array(dataX[:,-1,idx]-pred_test), 'y', label='dist')
#
# # for i in range(120, dataX.shape[0], 120):
#     # plt.vlines(i, 0, 20, colors = "r", linestyles="dashed")
#
# pp = [1,2,3] # [0,1,2,3,4,5,6,7,8,9]
# for i in range(dataX.shape[0]):
# # for i in pp:
#     plt.plot(plotX[i, :], label=i)
#
# plt.legend(loc='best')
# plt.show()

# draw all time and all floor
dataX, _ = process2(data_dir='../train_data/up_peak_normal')

# for i in range(4):
#     plt.figure()
#     plt.title('floor %d-%d' % (i*4+1, i*4+4))
#     for j in range(4):
#         floor_idx = i*4+j
#         plt.subplot(221+j)
#         plotX = dataX[:,:,floor_idx]
#         # pp = [0, 2, 4, 6]  # [0,1,2,3,4,5,6,7,8,9]
#         # plotX_mean1 = np.mean(plotX[:10, :], axis=0)
#         # plotX_mean2 = np.mean(plotX[10:20, :], axis=0)
#         # plotX_mean3 = np.mean(plotX[20:, :], axis=0)
#         # plt.plot(plotX_mean1, label='mean1')
#         # plt.plot(plotX_mean2, label='mean2')
#         # plt.plot(plotX_mean3, label='mean3')
#
#         # for k in pp:
#         # for k in range(dataX.shape[0]):
#         #     plt.plot(plotX[k, :], label=k)
#         #     plt.scatter(np.arange(plotX.shape[1]), plotX[k, :], s=3, label=k)
#         plt.legend(loc='best')
#     plt.show()
plt.rcParams['font.sans-serif']=['SimHei'] #用来正常显示中文标签
plt.figure()
plt.title('31天数据中以第1层为出发层的平均人数与时间的关系')
plotX = dataX[:,:,0]
plotX_mean = np.mean(plotX, axis=0)
plt.plot(plotX_mean)
plt.xlabel('时间（分钟）')
plt.ylabel('平均出现人数')
plt.show()
# # 累积函数
# # draw all time and all floor
# dataX, _ = process2()
#
# for i in range(4):
#     plt.figure()
#     plt.title('floor %d-%d' % (i*4+1, i*4+4))
#     for j in range(4):
#         floor_idx = i*4+j
#         plt.subplot(221+j)
#         plotX = dataX[:,:,floor_idx]
#         # plotX = np.cumsum(plotX, axis=1)
#         pp = [0, 2, 4, 6]  # [0,1,2,3,4,5,6,7,8,9]
#         for k in pp:
#         # for k in range(dataX.shape[0]):
#             plt.plot(plotX[k, :], label=k)
#             # plt.scatter(np.arange(plotX.shape[1]), plotX[k, :], s=3, label=k)
#         plt.legend(loc='best')
#     plt.show()



# # just draw down
# dataX, _ = process2()
# idx = 0
# plt.figure()
# plt.title('day %d' % (idx+1))
# plotX = dataX[idx,:,:]
# for j in range(4):
#     plt.subplot(221+j)
#     for i in range(4):
#         plt.plot(plotX[:, j*4+i], label='floor %d'%(j*4+i+1))
#     plt.ylim((0,4))
#     plt.legend(loc='best')
# plt.show()