import os
import numpy as np
import pickle
import glob
from csv import reader, writer
import queue

data_dir = './down_data'
data_file = './data/4Ele16FloorUpPeakFlow1_elvx.csv'
collected_data = queue.Queue()
dt = 60
t = 3600
iter_num = t // dt
floor_num = 16

save_dir = './out_data'
save_start_file = 'visualize_start.csv'
save_end_file = 'visualize_end.csv'

files = os.listdir(data_dir)


def process(look_back=5, save=False):
    data_x = []
    data_y = []
    max_value = 0.0
    for file in files:
        data_file = os.path.join(data_dir, file)
        start_data = [[0 for _ in range(floor_num)] for i in range(iter_num)]
        end_data = [[0 for _ in range(floor_num)] for i in range(iter_num)]
        with open(data_file, 'rt', encoding='utf8', errors='ignore') as f:
            r = reader(f)
            row = None
            for i in range(274):
                row = next(r)
            while True:
                time, start_level, end_level = row[0], int(row[1].replace('Level ', ''))-1, int(row[2].replace('Level ', ''))-1
                next_person_time = time.split(':')
                nt = int(next_person_time[-2]) * 60 + float(next_person_time[-1])
                # print(nt, int(nt)//dt)
                start_data[int(nt)//dt][start_level] += 1
                end_data[int(nt)//dt][end_level] += 1
                row = next(r)
                if len(row) < 14 or row[0]=='':
                    break
            if save:
                save_start_file = os.path.join(save_dir, 'start_'+file)
                save_end_file = os.path.join(save_dir, 'end_'+file)
                with open(save_start_file, 'w', newline='') as wf:
                    w = writer(wf)
                    for d in start_data:
                        w.writerow(d)
                with open(save_end_file, 'w', newline='') as wf:
                    w = writer(wf)
                    for d in end_data:
                        w.writerow(d)

        # print(start_data)
        tmp_max = np.max(start_data)
        if tmp_max > max_value:
            max_value = tmp_max
        # min_value = np.min(start_data)
        # datas = list(map(lambda x: (x-min_value) / (max_value-min_value), start_data))
        # m = np.mean(start_data)
        # v = np.var(start_data)
        # datas = list(map(lambda x: (x-m) / v, start_data))
        # max_value = np.max(datas)
        # min_value = np.min(datas)
        # print(max_value)
        # print(min_value)
        # print(m)
        # print(v)
        # print(datas)
        for i in range(len(start_data)-look_back):
            data_x.append(start_data[i:i+look_back])
            data_y.append(start_data[i+1:i+look_back+1])
    # return np.asarray(data_x) / max_value, np.asarray(data_y) / max_value
    return np.asarray(data_x), np.asarray(data_y)


# x, y = process(save=True)
# print(len(x))
# print(len(y))


def process2(data_dir='./down_data'):
    data_x = []
    data_y = []
    max_value = 0.0
    files = os.listdir(data_dir)
    for file in files:
        data_file = os.path.join(data_dir, file)
        start_data = [[0 for _ in range(floor_num)] for i in range(iter_num)]
        end_data = [[0 for _ in range(floor_num)] for i in range(iter_num)]
        with open(data_file, 'rt', encoding='utf8', errors='ignore') as f:
            r = reader(f)
            row = None
            for i in range(274):
                row = next(r)
            while True:
                time, start_level, end_level = row[0], int(row[1].replace('Level ', ''))-1, int(row[2].replace('Level ', ''))-1
                next_person_time = time.split(':')
                nt = int(next_person_time[-2]) * 60 + float(next_person_time[-1])
                # print(nt, int(nt)//dt)
                start_data[int(nt)//dt][start_level] += 1
                end_data[int(nt)//dt][end_level] += 1
                row = next(r)
                if len(row) < 14 or row[0]=='':
                    break

        # print(start_data)
        tmp_max = np.max(start_data)
        if tmp_max > max_value:
            max_value = tmp_max
        data_x.append(start_data)
    # return np.asarray(data_x) / max_value, np.asarray(data_y) / max_value
    return np.asarray(data_x), np.asarray(data_y)