import os
import sys
import glob
import pickle
import random
from smec_liftsim.utils import EPSILON
from smec_liftsim.utils import PersonType
from smec_liftsim.mansion_configs import MansionConfig
from smec_liftsim.person_generators import PersonGeneratorBase

from offline_tools.generate_dataset import generate_dataset_from_csv_to_pipline
import numpy as np


class FixedDataGenerator(PersonGeneratorBase):
    """
    Fetch data from disk and generate person data.
    """
    def __init__(self, data_file='../4Ele16FloorUpPeakFlowUpPeakMode1_elvx.csv', data_of_section=''):
        super().__init__()
        self._cur_id = 0
        self.data_file = data_file
        self.data_of_section = data_of_section

        # generate dataset
        self.data, self.used_ele = generate_dataset_from_csv_to_pipline(data_file, data_of_section=data_of_section)
        self.next_person = None if self.data.empty() else self.data.get()
        self.done = False

    def reset(self):
        self._cur_id = 0
        self.data, self.used_ele = generate_dataset_from_csv_to_pipline(self.data_file, data_of_section=self.data_of_section)
        self.next_person = None if self.data.empty() else self.data.get()
        self.done = False

    def generate_person(self):
        """
        Generate Random Persons from Poisson Distribution
        Returns:
          List of Random Persons
        """
        ret_persons = []
        cur_time = self._config.raw_time

        while self.next_person is not None and cur_time >= self.next_person['appear_time']:
            # generate this person
            ret_persons.append(
                PersonType(
                    self._cur_id,
                    self.next_person['m'],
                    self.next_person['start_level'],
                    self.next_person['end_level'],
                    cur_time,
                    self.next_person['standard_ele']
                ))
            self._cur_id += 1
            if not self.data.empty():
                self.next_person = self.data.get()
            else:
                self.next_person = None
                self.done = True
        return ret_persons

